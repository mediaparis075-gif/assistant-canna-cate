import { useState, useEffect, useRef, useCallback } from 'react';

// Extend the Window interface to include SpeechRecognition
declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}

const useSpeechRecognition = () => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [browserSupportsSpeechRecognition, setBrowserSupportsSpeechRecognition] = useState(false);
  
  const recognitionRef = useRef<any>(null);
  const manualStop = useRef(false);
  const finalizedTranscriptRef = useRef('');

  useEffect(() => {
    if (typeof window === 'undefined') {
        setBrowserSupportsSpeechRecognition(false);
        return;
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      setBrowserSupportsSpeechRecognition(true);
      if (!recognitionRef.current) {
        recognitionRef.current = new SpeechRecognition();
      }
      const recognition = recognitionRef.current;
      recognition.continuous = true;
      recognition.lang = 'fr-FR';
      recognition.interimResults = true;

      recognition.onresult = (event: any) => {
        let sessionFinal = '';
        let sessionInterim = '';

        for (let i = 0; i < event.results.length; ++i) {
            if (event.results[i].isFinal) {
                sessionFinal += event.results[i][0].transcript;
            } else {
                sessionInterim += event.results[i][0].transcript;
            }
        }
        
        const base = finalizedTranscriptRef.current ? finalizedTranscriptRef.current.trim() + ' ' : '';
        setTranscript(base + sessionFinal + sessionInterim);
      };

      recognition.onerror = (event: any) => {
        console.error('Speech recognition error', event.error);
        setIsListening(false);
      };
      
      recognition.onend = () => {
        if (transcript.trim().length > 0) {
            finalizedTranscriptRef.current = transcript.trim();
        }

        if (manualStop.current) {
          setIsListening(false);
        } else if (isListening && recognitionRef.current) {
          try {
            recognitionRef.current.start();
          } catch(e) {
            console.error("Speech recognition auto-restart failed", e);
            setIsListening(false);
          }
        } else {
            setIsListening(false);
        }
      };

    } else {
        setBrowserSupportsSpeechRecognition(false);
    }

    return () => {
        if (recognitionRef.current) {
            recognitionRef.current.onend = null;
            recognitionRef.current.onresult = null;
            recognitionRef.current.onerror = null;
        }
    };
  }, [transcript, isListening]); 

  const startListening = () => {
    if (recognitionRef.current && !isListening) {
      setTranscript('');
      finalizedTranscriptRef.current = '';
      manualStop.current = false;
      try {
        recognitionRef.current.start();
        setIsListening(true);
      } catch (e) {
        console.error("Could not start speech recognition:", e);
        setIsListening(false);
      }
    }
  };

  const stopListening = () => {
    if (recognitionRef.current && isListening) {
      manualStop.current = true;
      recognitionRef.current.stop();
    }
  };

  const resetTranscript = useCallback(() => {
    finalizedTranscriptRef.current = '';
    setTranscript('');
  }, []);

  return {
    isListening,
    transcript,
    startListening,
    stopListening,
    resetTranscript,
    browserSupportsSpeechRecognition: browserSupportsSpeechRecognition,
  };
};

export default useSpeechRecognition;