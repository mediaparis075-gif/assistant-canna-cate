import { Credentials, WPCategory } from '../types';

// La validation via /users/me est robuste et conservée.
export const validateWpConnection = async (credentials: Credentials): Promise<boolean> => {
  const { wpUrl, username, appPassword } = credentials;
  const auth = btoa(`${username}:${appPassword}`);
  try {
    const response = await fetch(`${wpUrl}/wp-json/wp/v2/users/me?context=edit`, {
      headers: {
        'Authorization': `Basic ${auth}`,
      }
    });
    return response.ok;
  } catch (error) {
    console.error('Erreur de validation de la connexion WordPress:', error);
    return false;
  }
};

// Utilisation de l'endpoint standard de WordPress pour les catégories de produits
export const getCategories = async (credentials: Credentials): Promise<WPCategory[]> => {
  const { wpUrl, username, appPassword } = credentials;
  const auth = btoa(`${username}:${appPassword}`);
  try {
    const response = await fetch(`${wpUrl}/wp-json/wp/v2/product_cat?per_page=100&_fields=id,name`, {
      headers: {
        'Authorization': `Basic ${auth}`,
      }
    });

    if (!response.ok) {
        throw new Error(`Erreur HTTP: ${response.status}`);
    }
    return await response.json();
  } catch (error) {
    console.error('Erreur lors de la récupération des catégories:', error);
    throw error;
  }
};

// Retour à la méthode de recherche directe via l'API standard, qui fonctionnait.
export const getCategoryByName = async (credentials: Credentials, categoryName: string): Promise<WPCategory | null> => {
  const { wpUrl, username, appPassword } = credentials;
  const auth = btoa(`${username}:${appPassword}`);
  
  try {
    // Utilisation du paramètre 'search' pour trouver la catégorie par nom
    const response = await fetch(`${wpUrl}/wp-json/wp/v2/product_cat?search=${encodeURIComponent(categoryName)}&context=edit`, {
      headers: {
        'Authorization': `Basic ${auth}`,
      }
    });

    if (!response.ok) {
        throw new Error(`Erreur HTTP: ${response.status}`);
    }

    const categories: WPCategory[] = await response.json();
    
    // Le paramètre 'search' peut retourner plusieurs résultats, on cherche la correspondance exacte.
    const exactMatch = categories.find(cat => cat.name.toLowerCase() === categoryName.toLowerCase());
    
    return exactMatch || null;

  } catch (error) {
    console.error(`Erreur lors de la recherche de la catégorie "${categoryName}":`, error);
    throw error;
  }
};

// Retour à la méthode de mise à jour standard via l'API REST de WordPress
export const updateCategoryMetadata = async (credentials: Credentials, categoryId: number, updateData: Partial<WPCategory>): Promise<WPCategory> => {
  const { wpUrl, username, appPassword } = credentials;
  const auth = btoa(`${username}:${appPassword}`);
  
  try {
    const payload: { [key: string]: any } = {};
    const meta: { [key: string]: any } = {};

    // Mappage des champs standards
    if (updateData.name) payload.name = updateData.name;
    if (updateData.slug) payload.slug = updateData.slug;
    if (updateData.description !== undefined) payload.description = updateData.description;

    // Mappage des champs Yoast dans un objet 'meta', comme attendu par l'API standard
    if (updateData._yoast_wpseo_title !== undefined) meta._yoast_wpseo_title = updateData._yoast_wpseo_title;
    if (updateData._yoast_wpseo_metadesc !== undefined) meta._yoast_wpseo_metadesc = updateData._yoast_wpseo_metadesc;
    if (updateData._yoast_wpseo_focuskw !== undefined) meta._yoast_wpseo_focuskw = updateData._yoast_wpseo_focuskw;

    if (Object.keys(meta).length > 0) {
      payload.meta = meta;
    }

    const response = await fetch(`${wpUrl}/wp-json/wp/v2/product_cat/${categoryId}`, {
      method: 'POST', // POST est utilisé pour les mises à jour dans l'API WP
      headers: {
        'Authorization': `Basic ${auth}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Erreur de mise à jour:', errorText);
      throw new Error(`Erreur HTTP: ${response.status}, détails: ${errorText}`);
    }

    return await response.json();
  } catch (error) {
    console.error('Erreur lors de la mise à jour de la catégorie:', error);
    throw error;
  }
};
